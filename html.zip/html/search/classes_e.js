var searchData=
[
  ['querydata_1156',['QueryData',['../structdoctest_1_1QueryData.html',1,'doctest']]]
];
