var searchData=
[
  ['approx_1080',['Approx',['../structdoctest_1_1Approx.html',1,'doctest']]],
  ['assertdata_1081',['AssertData',['../structdoctest_1_1AssertData.html',1,'doctest']]]
];
