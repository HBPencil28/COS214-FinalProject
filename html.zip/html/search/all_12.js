var searchData=
[
  ['unary_5fassert_991',['unary_assert',['../structdoctest_1_1detail_1_1ResultBuilder.html#a63a2a19638f4a761c70abd5563e2d23a',1,'doctest::detail::ResultBuilder::unary_assert()'],['../namespacedoctest_1_1detail.html#a0ffd8b760c2a9b355a1df02470fe2281',1,'doctest::detail::unary_assert()']]],
  ['underlying_5ftype_992',['underlying_type',['../structdoctest_1_1detail_1_1types_1_1underlying__type.html',1,'doctest::detail::types']]],
  ['unittest_2ecpp_993',['UnitTest.cpp',['../UnitTest_8cpp.html',1,'']]],
  ['update_994',['update',['../classCareStaff.html#ae930067c4982acac211b5b3c675651fa',1,'CareStaff::update() override'],['../classCareStaff.html#aa72ce2153c8e1617f872dc2971054356',1,'CareStaff::update(Plant *p) override'],['../classPlantObserver.html#a30eb57f71e57af4c4197b93baaab65bf',1,'PlantObserver::update()=0'],['../classPlantObserver.html#aa8bd2ab820400c51162712e4a65a12e8',1,'PlantObserver::update(Plant *p)=0']]]
];
