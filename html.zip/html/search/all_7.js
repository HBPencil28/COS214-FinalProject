var searchData=
[
  ['handlerequest_545',['handleRequest',['../classManager.html#ab2c61629e6005c7e54c2f31a1ca4e74d',1,'Manager::handleRequest()'],['../classNormalStaff.html#a55669fb5a8cbf6425da103e1b7527ce9',1,'NormalStaff::handleRequest()'],['../classSeniorManager.html#a685abccb5acb46e3ae2113db43e0fe14',1,'SeniorManager::handleRequest()'],['../classStaffHandler.html#abab6a2b7f873928adb18ab7e84a34a38',1,'StaffHandler::handleRequest()']]],
  ['has_5finsertion_5foperator_546',['has_insertion_operator',['../structdoctest_1_1detail_1_1has__insertion__operator.html',1,'doctest::detail']]],
  ['has_5finsertion_5foperator_3c_20t_2c_20decltype_28operator_3c_3c_28declval_3c_20std_3a_3aostream_20_26_20_3e_28_29_2c_20declval_3c_20const_20t_20_26_20_3e_28_29_29_2c_20void_28_29_29_3e_547',['has_insertion_operator&lt; T, decltype(operator&lt;&lt;(declval&lt; std::ostream &amp; &gt;(), declval&lt; const T &amp; &gt;()), void())&gt;',['../structdoctest_1_1detail_1_1has__insertion__operator_3_01T_00_01decltype_07operator_3_3_07declvald5a5a279653bbfeef238ad5c984744e2.html',1,'doctest::detail']]],
  ['hasnext_548',['hasNext',['../classPlantIterator.html#a829c4f1c6ff6545c9e73af3f7102c425',1,'PlantIterator']]],
  ['help_549',['help',['../structdoctest_1_1ContextOptions.html#a9d542a95ee03f61c233fff51e7461400',1,'doctest::ContextOptions']]],
  ['highcare_550',['HighCare',['../classHighCare.html',1,'HighCare'],['../classHighCare.html#a56fbd5b916d3becf5739e1bd7cfbc9b3',1,'HighCare::HighCare()']]],
  ['highcare_2ecpp_551',['HighCare.cpp',['../HighCare_8cpp.html',1,'']]],
  ['highcare_2eh_552',['HighCare.h',['../HighCare_8h.html',1,'']]]
];
